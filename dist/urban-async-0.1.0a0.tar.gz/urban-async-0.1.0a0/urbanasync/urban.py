"""
Copyright (c) 2017 kwugfighter

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import json, asyncio, aiohttp
from models import Term

class Client:

    def __init__(self, session=None):
        self.session = session or aiohttp.ClientSession()

    def __repr__(self):
        return "<urbanasync Client>"

    async def get_term(self, term: str):
        term = term.lower().replace(" ", "+")
        async with self.session as session:
            async with session.get("http://api.urbandictionary.com/v0/define?term={}".format(term)) as resp:
                if resp.status == 200:
                    raise ConnectionError("API is down at the moment. Please be patient.")
                data = resp.json()

        if data['result_type'] == "no_results":
            raise LookupError("Term does not exist.")

        return Term(data)



